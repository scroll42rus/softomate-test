"use strict";var applyContent=function(){chrome.storage.sync.get("data",function(t){if("data"in t){var n=Handlebars.compile($("#template").html());$("#container").html(n(t.data))}else $("#container").html("Can't load content. Try again later")})};document.addEventListener("DOMContentLoaded",function(){applyContent()});
//# sourceMappingURL=popup.js.map
